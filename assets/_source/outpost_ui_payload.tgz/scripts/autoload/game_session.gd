extends Node

const MAX_PLAYERS := 4
const LOADING_SCENE := "res://scenes/ui/loading_screen.tscn"

var is_coop := false
var pending_scene := ""
