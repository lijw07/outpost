extends Control

signal mode_selected(coop: bool)
signal back_requested

@onready var _single_player_button: Button = %SinglePlayerButton

func _ready() -> void:
	_single_player_button.pressed.connect(_on_mode_pressed.bind(false))
	%CoopButton.pressed.connect(_on_mode_pressed.bind(true))
	%BackButton.pressed.connect(back_requested.emit)

func focus_first() -> void:
	_single_player_button.grab_focus()

func _on_mode_pressed(coop: bool) -> void:
	mode_selected.emit(coop)
