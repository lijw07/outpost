extends Node

signal settings_applied

const CONFIG_PATH := "user://settings.cfg"

const RESOLUTIONS: Array[Vector2i] = [
	Vector2i(1280, 720),
	Vector2i(1366, 768),
	Vector2i(1600, 900),
	Vector2i(1920, 1080),
	Vector2i(2560, 1440),
]

const AUDIO_BUSES: Array[String] = ["Master", "Music", "SFX"]

const REMAPPABLE_ACTIONS := {
	"move_up": "Move Up",
	"move_down": "Move Down",
	"move_left": "Move Left",
	"move_right": "Move Right",
	"sprint": "Sprint",
	"interact": "Interact",
	"attack": "Attack",
	"build_mode": "Build Mode",
	"inventory": "Inventory",
	"pause": "Pause",
}

enum WindowMode { WINDOWED, BORDERLESS, FULLSCREEN }

var window_mode := WindowMode.WINDOWED
var resolution_index := 0
var vsync_enabled := true
var bus_volumes := {}

var _default_events := {}

func _ready() -> void:
	_capture_default_events()
	_load_defaults()
	load_settings()
	apply_all()

func apply_all() -> void:
	apply_display()
	apply_audio()
	settings_applied.emit()

func apply_display() -> void:
	var window := get_window()
	match window_mode:
		WindowMode.BORDERLESS:
			window.borderless = false
			window.mode = Window.MODE_FULLSCREEN
		WindowMode.FULLSCREEN:
			window.borderless = false
			window.mode = Window.MODE_EXCLUSIVE_FULLSCREEN
		_:
			window.mode = Window.MODE_WINDOWED
			window.borderless = false
			_apply_resolution()
	DisplayServer.window_set_vsync_mode(
		DisplayServer.VSYNC_ENABLED if vsync_enabled else DisplayServer.VSYNC_DISABLED
	)

func apply_audio() -> void:
	for bus_name in AUDIO_BUSES:
		var index := AudioServer.get_bus_index(bus_name)
		if index < 0:
			continue
		var linear: float = bus_volumes.get(bus_name, 1.0)
		AudioServer.set_bus_volume_db(index, linear_to_db(linear))
		AudioServer.set_bus_mute(index, linear <= 0.001)

func set_window_mode(mode: int) -> void:
	window_mode = mode
	apply_display()
	save_settings()

func set_resolution_index(index: int) -> void:
	resolution_index = clampi(index, 0, RESOLUTIONS.size() - 1)
	if window_mode == WindowMode.WINDOWED:
		_apply_resolution()
	save_settings()

func set_vsync(enabled: bool) -> void:
	vsync_enabled = enabled
	DisplayServer.window_set_vsync_mode(
		DisplayServer.VSYNC_ENABLED if enabled else DisplayServer.VSYNC_DISABLED
	)
	save_settings()

func set_bus_volume(bus_name: String, linear: float) -> void:
	bus_volumes[bus_name] = clampf(linear, 0.0, 1.0)
	apply_audio()
	save_settings()

func get_bus_volume(bus_name: String) -> float:
	return bus_volumes.get(bus_name, 1.0)

func get_binding(action: String) -> InputEvent:
	if not InputMap.has_action(action):
		return null
	var events := InputMap.action_get_events(action)
	return events[0] if not events.is_empty() else null

func set_binding(action: String, event: InputEvent) -> void:
	if not InputMap.has_action(action):
		return
	for other in REMAPPABLE_ACTIONS:
		if other == action:
			continue
		var existing := get_binding(other)
		if existing != null and existing.is_match(event, false):
			InputMap.action_erase_events(other)
	InputMap.action_erase_events(action)
	InputMap.action_add_event(action, event)
	save_settings()
	settings_applied.emit()

func reset_bindings() -> void:
	for action in REMAPPABLE_ACTIONS:
		if not InputMap.has_action(action):
			continue
		InputMap.action_erase_events(action)
		for event in _default_events.get(action, []):
			InputMap.action_add_event(action, event)
	save_settings()
	settings_applied.emit()

func reset_all() -> void:
	_load_defaults()
	reset_bindings()
	apply_all()
	save_settings()

func save_settings() -> void:
	var config := ConfigFile.new()
	config.set_value("display", "window_mode", int(window_mode))
	config.set_value("display", "resolution_index", resolution_index)
	config.set_value("display", "vsync", vsync_enabled)
	for bus_name in AUDIO_BUSES:
		config.set_value("audio", bus_name, get_bus_volume(bus_name))
	for action in REMAPPABLE_ACTIONS:
		config.set_value("input", action, serialize_event(get_binding(action)))
	config.save(CONFIG_PATH)

func load_settings() -> void:
	var config := ConfigFile.new()
	if config.load(CONFIG_PATH) != OK:
		return
	window_mode = config.get_value("display", "window_mode", int(window_mode))
	resolution_index = config.get_value("display", "resolution_index", resolution_index)
	vsync_enabled = config.get_value("display", "vsync", vsync_enabled)
	for bus_name in AUDIO_BUSES:
		bus_volumes[bus_name] = config.get_value("audio", bus_name, get_bus_volume(bus_name))
	for action in REMAPPABLE_ACTIONS:
		var encoded: String = config.get_value("input", action, "")
		var event := deserialize_event(encoded)
		if event != null and InputMap.has_action(action):
			InputMap.action_erase_events(action)
			InputMap.action_add_event(action, event)

static func serialize_event(event: InputEvent) -> String:
	if event is InputEventKey:
		return "key:%d" % (event as InputEventKey).physical_keycode
	if event is InputEventMouseButton:
		return "mouse:%d" % (event as InputEventMouseButton).button_index
	if event is InputEventJoypadButton:
		return "joy:%d" % (event as InputEventJoypadButton).button_index
	return ""

static func deserialize_event(encoded: String) -> InputEvent:
	var parts := encoded.split(":")
	if parts.size() != 2 or not parts[1].is_valid_int():
		return null
	var value := int(parts[1])
	match parts[0]:
		"key":
			var key_event := InputEventKey.new()
			key_event.physical_keycode = value
			return key_event
		"mouse":
			var mouse_event := InputEventMouseButton.new()
			mouse_event.button_index = value
			return mouse_event
		"joy":
			var joy_event := InputEventJoypadButton.new()
			joy_event.button_index = value
			return joy_event
	return null

static func event_display_name(event: InputEvent) -> String:
	if event == null:
		return "Unbound"
	if event is InputEventKey:
		var key_event := event as InputEventKey
		var keycode := DisplayServer.keyboard_get_keycode_from_physical(key_event.physical_keycode)
		return OS.get_keycode_string(keycode)
	if event is InputEventMouseButton:
		match (event as InputEventMouseButton).button_index:
			MOUSE_BUTTON_LEFT:
				return "Mouse Left"
			MOUSE_BUTTON_RIGHT:
				return "Mouse Right"
			MOUSE_BUTTON_MIDDLE:
				return "Mouse Middle"
			MOUSE_BUTTON_WHEEL_UP:
				return "Wheel Up"
			MOUSE_BUTTON_WHEEL_DOWN:
				return "Wheel Down"
			_:
				return "Mouse %d" % (event as InputEventMouseButton).button_index
	if event is InputEventJoypadButton:
		return "Pad %d" % (event as InputEventJoypadButton).button_index
	return event.as_text()

func _apply_resolution() -> void:
	var target: Vector2i = RESOLUTIONS[clampi(resolution_index, 0, RESOLUTIONS.size() - 1)]
	var window := get_window()
	window.size = target
	var screen := window.current_screen
	window.position = DisplayServer.screen_get_position(screen) \
		+ (DisplayServer.screen_get_size(screen) - target) / 2

func _capture_default_events() -> void:
	for action in REMAPPABLE_ACTIONS:
		if InputMap.has_action(action):
			_default_events[action] = InputMap.action_get_events(action).duplicate()

func _load_defaults() -> void:
	window_mode = WindowMode.WINDOWED
	vsync_enabled = true
	resolution_index = _closest_resolution_index()
	bus_volumes = {"Master": 0.8, "Music": 0.7, "SFX": 0.8}

func _closest_resolution_index() -> int:
	var current := get_window().size
	for i in RESOLUTIONS.size():
		if RESOLUTIONS[i] == current:
			return i
	return 0
