extends Control

const GAME_SCENE_PATH := "res://scenes/world/game.tscn"

@onready var _title_panel: Control = $Screens/TitlePanel
@onready var _mode_select_panel: Control = $Screens/ModeSelectPanel
@onready var _settings_panel: Control = $Screens/SettingsPanel
@onready var _extras_panel: Control = $Screens/ExtrasPanel

var _history: Array[Control] = []
var _current: Control

func _ready() -> void:
	_title_panel.play_requested.connect(_show_panel.bind(_mode_select_panel))
	_title_panel.settings_requested.connect(_show_panel.bind(_settings_panel))
	_title_panel.extras_requested.connect(_show_panel.bind(_extras_panel))
	_title_panel.quit_requested.connect(_quit)
	_mode_select_panel.mode_selected.connect(_start_game)
	_mode_select_panel.back_requested.connect(_go_back)
	_settings_panel.back_requested.connect(_go_back)
	_extras_panel.back_requested.connect(_go_back)
	for panel in [_title_panel, _mode_select_panel, _settings_panel, _extras_panel]:
		panel.hide()
	_show_panel(_title_panel)

func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_cancel") and not _history.is_empty():
		get_viewport().set_input_as_handled()
		_go_back()

func _show_panel(panel: Control) -> void:
	if _current != null:
		_current.hide()
		_history.push_back(_current)
	_current = panel
	panel.show()
	panel.focus_first()

func _go_back() -> void:
	if _history.is_empty():
		return
	_current.hide()
	_current = _history.pop_back()
	_current.show()
	_current.focus_first()

func _start_game(coop: bool) -> void:
	GameSession.is_coop = coop
	GameSession.pending_scene = GAME_SCENE_PATH
	if not ResourceLoader.exists(GAME_SCENE_PATH):
		push_warning("No game scene at %s yet." % GAME_SCENE_PATH)
		return
	get_tree().change_scene_to_file(GameSession.LOADING_SCENE)

func _quit() -> void:
	get_tree().quit()
