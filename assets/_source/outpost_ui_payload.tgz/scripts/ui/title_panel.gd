extends Control

signal play_requested
signal settings_requested
signal extras_requested
signal quit_requested

@onready var _play_button: Button = %PlayButton

func _ready() -> void:
	_play_button.pressed.connect(play_requested.emit)
	%SettingsButton.pressed.connect(settings_requested.emit)
	%ExtrasButton.pressed.connect(extras_requested.emit)
	%QuitButton.pressed.connect(quit_requested.emit)

func focus_first() -> void:
	_play_button.grab_focus()
