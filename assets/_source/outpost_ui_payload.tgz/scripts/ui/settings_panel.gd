extends Control

signal back_requested

const KEY_BIND_ROW := preload("res://scenes/ui/components/key_bind_row.tscn")

@onready var _window_mode_option: OptionButton = %WindowModeOption
@onready var _resolution_option: OptionButton = %ResolutionOption
@onready var _vsync_check: CheckBox = %VsyncCheck
@onready var _bind_list: VBoxContainer = %BindList
@onready var _back_button: Button = %BackButton
@onready var _volume_sliders := {
	"Master": %MasterSlider,
	"Music": %MusicSlider,
	"SFX": %SfxSlider,
}
@onready var _volume_values := {
	"Master": %MasterValue,
	"Music": %MusicValue,
	"SFX": %SfxValue,
}

func _ready() -> void:
	for label in ["Windowed", "Borderless Fullscreen", "Fullscreen"]:
		_window_mode_option.add_item(label)
	for resolution in Settings.RESOLUTIONS:
		_resolution_option.add_item("%d x %d" % [resolution.x, resolution.y])
	_window_mode_option.item_selected.connect(_on_window_mode_selected)
	_resolution_option.item_selected.connect(Settings.set_resolution_index)
	_vsync_check.toggled.connect(Settings.set_vsync)
	for bus_name in _volume_sliders:
		_volume_sliders[bus_name].value_changed.connect(_on_volume_changed.bind(bus_name))
	%ResetControlsButton.pressed.connect(Settings.reset_bindings)
	%ResetAllButton.pressed.connect(Settings.reset_all)
	_back_button.pressed.connect(back_requested.emit)
	Settings.settings_applied.connect(_refresh)
	_build_bind_rows()
	_refresh()

func focus_first() -> void:
	_window_mode_option.grab_focus()

func _build_bind_rows() -> void:
	for action in Settings.REMAPPABLE_ACTIONS:
		var row := KEY_BIND_ROW.instantiate()
		row.setup(action, Settings.REMAPPABLE_ACTIONS[action])
		_bind_list.add_child(row)

func _refresh() -> void:
	_window_mode_option.selected = int(Settings.window_mode)
	_resolution_option.selected = Settings.resolution_index
	_resolution_option.disabled = Settings.window_mode != Settings.WindowMode.WINDOWED
	_vsync_check.set_pressed_no_signal(Settings.vsync_enabled)
	for bus_name in _volume_sliders:
		var slider: HSlider = _volume_sliders[bus_name]
		slider.set_value_no_signal(Settings.get_bus_volume(bus_name) * 100.0)
		_volume_values[bus_name].text = "%d%%" % roundi(slider.value)
	for row in _bind_list.get_children():
		row.refresh()

func _on_window_mode_selected(index: int) -> void:
	Settings.set_window_mode(index)
	_refresh()

func _on_volume_changed(value: float, bus_name: String) -> void:
	Settings.set_bus_volume(bus_name, value / 100.0)
	_volume_values[bus_name].text = "%d%%" % roundi(value)
